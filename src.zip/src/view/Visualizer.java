package view;

import model.VectorSpace;

public interface Visualizer {
    // מקבל שני מרחבים: אחד למתמטיקה ואחד לתצוגה
    void display(VectorSpace fullSpace, VectorSpace pcaSpace);

    void highlight(String word);
}
package logic_commands;

import logic.AnalysisService;
import model.SearchResult;
import utils.AppConstants;
import view.SceneRenderer;
import javafx.scene.control.Label;

public class ComputeAnalogyCommand extends AbstractVisualCommand {
    private final AnalysisService service;
    private final String wordA, wordB, wordC;

    public ComputeAnalogyCommand(AnalysisService service, SceneRenderer renderer, Label resultLabel, String prevWord, String a, String b, String c) {
        super(renderer, resultLabel, prevWord);
        this.service = service;
        this.wordA = a.trim();
        this.wordB = b.trim();
        this.wordC = c.trim();
    }

    @Override
    protected void doExecute() {
        SearchResult result = service.computeAnalogy(wordA, wordB, wordC);
        if (result == null) {
            resultLabel.setText("Error computing analogy.");
            return;
        }

        String resultWord = result.getWord();
        this.targetWord = resultWord; // המצלמה תתמקד בתוצאה

        renderer.highlightWord(wordA, AppConstants.COLOR_TARGET, AppConstants.RADIUS_CENTROID);
        renderer.highlightWord(wordB, AppConstants.COLOR_TARGET, AppConstants.RADIUS_CENTROID);
        renderer.highlightWord(wordC, AppConstants.COLOR_TARGET, AppConstants.RADIUS_CENTROID);
        renderer.highlightWord(resultWord, AppConstants.COLOR_ANALOGY_RESULT, AppConstants.RADIUS_ANALOGY_RESULT);

        renderer.drawLineBetweenWords(wordA, resultWord);
        renderer.drawLineBetweenWords(wordC, resultWord);
        renderer.zoomToWord(resultWord);

        resultLabel.setText(String.format("%s - %s + %s = %s", wordA, wordB, wordC, resultWord));
    }
}
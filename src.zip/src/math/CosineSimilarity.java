package math;

import model.WordEmbedding;
import java.util.Comparator;
import java.util.Map;
public class CosineSimilarity implements Distance {
    @Override
    public double calculate(WordEmbedding v1, WordEmbedding v2) {
        double dotProduct = 0.0, normA = 0.0, normB = 0.0;
        int dim = Math.min(v1.getDimension(), v2.getDimension());
        for (int i = 0; i < dim; i++) {
            dotProduct += v1.getCoordinate(i) * v2.getCoordinate(i);
            normA += Math.pow(v1.getCoordinate(i), 2);
            normB += Math.pow(v2.getCoordinate(i), 2);
        }
        if (normA == 0.0 || normB == 0.0) return 0.0;
        return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }

    @Override
    public String getName() { return "Cosine Similarity"; }

    @Override
    public Comparator<Map.Entry<WordEmbedding, Double>> getResultComparator() {
        return (e1, e2) -> Double.compare(e2.getValue(), e1.getValue());
    }
}
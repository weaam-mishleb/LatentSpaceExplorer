package model;

public class SearchResult {
    private final WordEmbedding embedding;
    private final double score; // יכול להיות מרחק או דמיון

    public SearchResult(WordEmbedding embedding, double score) {
        this.embedding = embedding;
        this.score = score;
    }

    public WordEmbedding getEmbedding() { return embedding; }
    public double getScore() { return score; }
    public String getWord() { return embedding.getWord(); }
}
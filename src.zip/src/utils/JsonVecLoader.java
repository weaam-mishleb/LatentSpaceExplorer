package utils;

import exceptions.DataLoadingException;
import model.VectorSpace;
import model.WordEmbedding;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

// עכשיו הוא מממש את הממשק, מה שנותן נקודות זכות על Polymorphism!
public class JsonVecLoader implements IDataLoader {

    @Override
    public void loadVectors(String jsonFilePath, VectorSpace space) throws DataLoadingException {
        System.out.println("reading vectors from: " + jsonFilePath);
        StringBuilder contentBuilder = new StringBuilder();

        try (BufferedReader br = new BufferedReader(new FileReader(jsonFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                contentBuilder.append(line);
            }
        } catch (IOException e) {
            // עוטפים שגיאת קלט/פלט בשגיאה שלנו
            throw new DataLoadingException("Failed to read the JSON file: " + jsonFilePath, e);
        }

        String json = contentBuilder.toString().trim();
        if (json.startsWith("[") && json.endsWith("]")) {
            json = json.substring(1, json.length() - 1);
        }
        String[] objects = json.split("\\},\\s*\\{");

        int count = 0;
        for (String obj : objects) {
            obj = obj.replace("{", "").replace("}", "");
            try {
                String word = extractValue(obj, "\"word\":");
                if (word != null) word = word.replace("\"", "").trim();
                String vectorStr = extractValue(obj, "\"vector\":");
                if (word != null && vectorStr != null) {
                    vectorStr = vectorStr.replace("[", "").replace("]", "");
                    String[] numStrings = vectorStr.split(",");
                    double[] vector = new double[numStrings.length];
                    for (int i = 0; i < numStrings.length; i++) {
                        vector[i] = Double.parseDouble(numStrings[i].trim());
                    }
                    space.addWord(new WordEmbedding(word, vector));
                    count++;
                }
            } catch (Exception e) {
                System.err.println("Warning: Corrupted data " + e.getMessage());
            }
        }
        System.out.println("loaded " + count + " words into VectorSpace.");
    }

    private String extractValue(String text, String key) {
        int startIdx = text.indexOf(key);
        if (startIdx == -1) return null;
        startIdx += key.length();
        while (startIdx < text.length() && Character.isWhitespace(text.charAt(startIdx))) {
            startIdx++;
        }
        int endIdx;
        if (text.charAt(startIdx) == '[') {
            endIdx = text.indexOf("]", startIdx);
            if (endIdx != -1) endIdx++;
        } else {
            endIdx = text.indexOf(", \"", startIdx);
            if (endIdx == -1) endIdx = text.length();
        }
        if (endIdx == -1) return null;
        return text.substring(startIdx, endIdx).trim();
    }
}
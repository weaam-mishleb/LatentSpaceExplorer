package controller;

import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;
import logic.AnalysisService;
import logic.Command;
import logic.CommandManager;
import logic_commands.*;
import math.CosineSimilarity;
import math.Distance;
import math.EuclideanDistance;
import model.VectorSpace;
import view.SceneRenderer;

import java.util.HashMap;
import java.util.Map;

public class MainController {
    private final AnalysisService service;
    private final CommandManager commandManager = new CommandManager();
    private final SceneRenderer renderer;
    private final Label resultLabel;
    private final ToggleGroup metricGroup;
    private final Map<String, Distance> distanceMetrics = new HashMap<>();
    private String currentFocusWord = null;

    public MainController(VectorSpace space, SceneRenderer renderer, Label resultLabel, ToggleGroup metricGroup) {
        distanceMetrics.put("cosine", new CosineSimilarity());
        distanceMetrics.put("euclidean", new EuclideanDistance());
        this.service = new AnalysisService(space, distanceMetrics.get("cosine"));
        this.renderer = renderer;
        this.resultLabel = resultLabel;
        this.metricGroup = metricGroup;
    }

    public void undo() {
        commandManager.undo();
    }

    public void redo() {
        commandManager.redo();
    }

    public void executeWithHistory(Runnable action, String wordToFocus) {
        String prevWord = currentFocusWord;
        Command cmd = new Command() {
            @Override
            public void execute() {
                action.run();
                currentFocusWord = wordToFocus;
            }
            @Override
            public void undo() {
                renderer.clearLines();
                renderer.resetSphereColors();
                if (prevWord != null) {
                    renderer.highlightWord(prevWord, Color.CYAN, 12);
                    renderer.zoomToWord(prevWord);
                    resultLabel.setText("Undo: Back to " + prevWord);
                } else {
                    renderer.resetCamera();
                    resultLabel.setText("Undo: Reset view");
                }
                currentFocusWord = prevWord;
            }
        };
        commandManager.executeCommand(cmd);
    }

    public void zoomToWordAction(String word) {
        ZoomToWordCommand cmd = new ZoomToWordCommand(renderer, resultLabel, currentFocusWord, word);
        commandManager.executeCommand(cmd);
        currentFocusWord = cmd.getTargetWord();
    }

    public void computeGroupCentroid(String input, int k) {
        ComputeCentroidCommand cmd = new ComputeCentroidCommand(service, renderer, resultLabel, currentFocusWord, input, k);
        commandManager.executeCommand(cmd);
        currentFocusWord = cmd.getTargetWord();
    }

    public void showProjection(String start, String end) {
        ShowProjectionCommand cmd = new ShowProjectionCommand(service, renderer, resultLabel, currentFocusWord, start, end);
        commandManager.executeCommand(cmd);
        currentFocusWord = cmd.getTargetWord();
    }

    public void calculateAndShowDistance(String w1, String w2) {
        CalculateDistanceCommand cmd = new CalculateDistanceCommand(service, renderer, resultLabel, currentFocusWord, w1, w2);
        commandManager.executeCommand(cmd);
        currentFocusWord = cmd.getTargetWord();
    }

    public void updateMetricStrategy() {
        RadioButton selected = (RadioButton) metricGroup.getSelectedToggle();
        if (selected == null) return;

        String type = (String) selected.getUserData();
        Distance selectedMetric = distanceMetrics.get(type);

        if (selectedMetric != null) {
            service.setMetric(selectedMetric);
            resultLabel.setText("Strategy: " + selectedMetric.getName());
        }

        renderer.clearLines();
        renderer.resetSphereColors();
    }


    public void showNearestNeighbors(String targetWord) {
        FindNeighborsCommand cmd = new FindNeighborsCommand(
                service, renderer, resultLabel, currentFocusWord, targetWord, 5
        );
        commandManager.executeCommand(cmd);
        currentFocusWord = cmd.getTargetWord(); // מעדכן את המילה הנוכחית
    }

    public void computeAnalogy(String a, String b, String c) {
        ComputeAnalogyCommand cmd = new ComputeAnalogyCommand(
                service, renderer, resultLabel, currentFocusWord, a, b, c
        );
        commandManager.executeCommand(cmd);
        currentFocusWord = cmd.getTargetWord(); // מעדכן את המילה הנוכחית
    }
}
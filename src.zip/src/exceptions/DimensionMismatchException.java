package exceptions;

public class DimensionMismatchException extends RuntimeException {
    public DimensionMismatchException(int expected, int actual) {
        super("Dimension mismatch: Expected " + expected + " dimensions, but got " + actual);
    }
}
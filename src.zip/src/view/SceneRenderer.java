package view;

import javafx.geometry.Point3D;
import javafx.scene.AmbientLight;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.PointLight;
import javafx.scene.SceneAntialiasing;
import javafx.scene.SubScene;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.Sphere;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Translate;
import model.VectorSpace;
import model.WordEmbedding;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class SceneRenderer {

    private final Group worldRoot = new Group();
    private final Group linesGroup = new Group();
    private PerspectiveCamera camera;
    private final Group labelsGroup = new Group();
    private final Map<Sphere, WordEmbedding> sphereToWordMap = new HashMap<>();
    private final Map<String, Sphere> wordToSphereMap = new HashMap<>();

    private final Rotate rotateX = new Rotate(0, Rotate.X_AXIS);
    private final Rotate rotateY = new Rotate(0, Rotate.Y_AXIS);
    private double mouseOldX, mouseOldY;

    private static final double SCALE = 200.0;
    private boolean is3DMode = true;

    private final Label floatingLabel;

    private Consumer<String> onWordClicked;

    public SceneRenderer(Label floatingLabel) {
        this.floatingLabel = floatingLabel;
        worldRoot.getChildren().add(linesGroup);
        worldRoot.getChildren().add(labelsGroup); // <-- הוספנו את זה!
        setupLighting();
    }
    public void setOnWordClicked(Consumer<String> onWordClicked) {
        this.onWordClicked = onWordClicked;
    }

    public SubScene createSubScene(double width, double height) {
        SubScene subScene = new SubScene(worldRoot, width, height, true, SceneAntialiasing.BALANCED);
        subScene.setFill(Color.WHITE);
        setupCamera(subScene);
        setupMouseControl(subScene);
        return subScene;
    }

    public void initializeSpace(VectorSpace space) {
        if (space != null) {
            for (WordEmbedding word : space.getAllEmbeddings()) {
                createSphereForWord(word);
            }
        }
    }

    private void setupLighting() {
        PointLight light = new PointLight(Color.WHITE);
        light.setTranslateX(-1000); light.setTranslateY(-1000); light.setTranslateZ(-2000);
        worldRoot.getChildren().addAll(light, new AmbientLight(Color.rgb(100, 100, 100)));
    }

    private void setupCamera(SubScene scene) {
        camera = new PerspectiveCamera(true);
        camera.setNearClip(0.1); camera.setFarClip(10000.0);
        resetCamera();
        Group cameraGroup = new Group(camera);
        worldRoot.getChildren().add(cameraGroup);
        scene.setCamera(camera);
    }

    private void setupMouseControl(SubScene scene) {
        scene.setOnMousePressed(event -> {
            mouseOldX = event.getSceneX();
            mouseOldY = event.getSceneY();
        });

        scene.setOnMouseDragged(event -> {
            double deltaX = event.getSceneX() - mouseOldX;
            double deltaY = event.getSceneY() - mouseOldY;

            // לחצן ימני - הזזה (Panning)
            if (event.isSecondaryButtonDown() || event.isMiddleButtonDown()) {
                camera.setTranslateX(camera.getTranslateX() - deltaX * 3.0);
                camera.setTranslateY(camera.getTranslateY() - deltaY * 3.0);
            }
            // לחצן שמאלי - סיבוב (Rotation)
            else {
                rotateY.setAngle(rotateY.getAngle() + deltaX * 0.4);
                rotateX.setAngle(rotateX.getAngle() - deltaY * 0.4);

                // --- התיקון הקריטי! ---
                // אנחנו מכריחים את העולם להתעדכן בזווית החדשה בכל שבריר שנייה של גרירה!
                worldRoot.getTransforms().setAll(rotateX, rotateY);
            }

            mouseOldX = event.getSceneX();
            mouseOldY = event.getSceneY();
        });

        scene.setOnScroll(event -> {
            camera.setTranslateZ(camera.getTranslateZ() + event.getDeltaY() * 5);
        });
    }

    public void resetCamera() {
        rotateX.setAngle(0);
        rotateY.setAngle(0);

        // גם כאן אנחנו מוודאים שהעולם מתאפס יחד עם הזווית
        worldRoot.getTransforms().setAll(rotateX, rotateY);

        camera.setTranslateX(0);
        camera.setTranslateY(0);
        camera.setTranslateZ(-3500);

        clearLines();
        resetSphereColors();
    }
    private void createSphereForWord(WordEmbedding word) {
        Sphere sphere = new Sphere(4, 8);
        PhongMaterial material = new PhongMaterial(Color.web("#004488"));
        material.setSpecularColor(Color.LIGHTBLUE);
        sphere.setMaterial(material);

        sphereToWordMap.put(sphere, word);
        wordToSphereMap.put(word.getWord(), sphere);

        sphere.setTranslateX(word.getCoordinate(0) * SCALE);
        sphere.setTranslateY(word.getCoordinate(1) * SCALE);
        sphere.setTranslateZ(word.getCoordinate(2) * SCALE);

        sphere.setOnMouseEntered(e -> {
            if (sphere.getRadius() < 5) highlightSphere(sphere, Color.ORANGE, 6);
            floatingLabel.setText(word.getWord());
            floatingLabel.setLayoutX(e.getSceneX() + 15);
            floatingLabel.setLayoutY(e.getSceneY() - 15);
            floatingLabel.setVisible(true);
            floatingLabel.toFront();
        });

        sphere.setOnMouseExited(e -> {
            if (sphere.getRadius() < 7) highlightSphere(sphere, Color.web("#004488"), 4);
            floatingLabel.setVisible(false);
        });
        sphere.setOnMouseClicked(e -> {
            if (e.isStillSincePress() && onWordClicked != null) {
                onWordClicked.accept(word.getWord());
                e.consume();
            }
        });

        worldRoot.getChildren().add(sphere);
    }

    public void updateAllPositions(int x, int y, int z, boolean is3DMode) {
        this.is3DMode = is3DMode;
        clearLines();
        for (Map.Entry<Sphere, WordEmbedding> entry : sphereToWordMap.entrySet()) {
            WordEmbedding word = entry.getValue();
            Sphere sphere = entry.getKey();
            sphere.setTranslateX(word.getCoordinate(x) * SCALE);
            sphere.setTranslateY(word.getCoordinate(y) * SCALE);
            sphere.setTranslateZ(is3DMode ? word.getCoordinate(z) * SCALE : 0);
        }
        if (!is3DMode) {
            rotateX.setAngle(0); rotateY.setAngle(0);
        }
    }

    public void zoomToWord(String word) {
        Sphere s = wordToSphereMap.get(word.trim());
        if (s != null) {
            // התיקון הקריטי: מחקנו את איפוסי הזווית!
            // המצלמה שומרת על הזווית שבה היית ורק מתקרבת לכדור
            camera.setTranslateX(s.getTranslateX());
            camera.setTranslateY(s.getTranslateY());
            camera.setTranslateZ(s.getTranslateZ() - 800);
        }
    }

    public void focusOnTwoPoints(String word1, String word2) {
        Sphere s1 = wordToSphereMap.get(word1.trim());
        Sphere s2 = wordToSphereMap.get(word2.trim());
        if (s1 != null && s2 != null) {
            Point3D p1 = toPoint(s1);
            Point3D p2 = toPoint(s2);
            Point3D mid = p1.midpoint(p2);

            // גם פה, המצלמה שומרת על זווית הראייה של המשתמש!
            camera.setTranslateX(mid.getX());
            camera.setTranslateY(mid.getY());
            camera.setTranslateZ(mid.getZ() - 1000);
        }
    }

    public void highlightWord(String word, Color c, double radius) {
        Sphere s = wordToSphereMap.get(word.trim());
        if (s != null) {
            highlightSphere(s, c, radius);

            javafx.scene.text.Text textLabel = new javafx.scene.text.Text(word.trim());
            textLabel.setFill(c);
            textLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");

            // מאפסים את המיקום הרגיל כדי להשתמש רק בטרנספורמציות חכמות
            textLabel.setTranslateX(0);
            textLabel.setTranslateY(0);
            textLabel.setTranslateZ(0);

            // מייצרים את הסיבוב ההפוך כדי שהטקסט יפנה אלינו
            javafx.scene.transform.Rotate invRotX = new javafx.scene.transform.Rotate(0, javafx.scene.transform.Rotate.X_AXIS);
            invRotX.angleProperty().bind(rotateX.angleProperty().multiply(-1));

            javafx.scene.transform.Rotate invRotY = new javafx.scene.transform.Rotate(0, javafx.scene.transform.Rotate.Y_AXIS);
            invRotY.angleProperty().bind(rotateY.angleProperty().multiply(-1));

            // סדר הפעולות פה הוא קריטי לאשליית התלת-ממד!
            // פעולה 1: מזיזים את הטקסט למרכז הכדור בעולם התלת-ממדי
            textLabel.getTransforms().add(new javafx.scene.transform.Translate(s.getTranslateX(), s.getTranslateY(), s.getTranslateZ()));

            // פעולה 2: מסובבים את הטקסט נגד תנועת העולם כדי שיסתכל עלינו
            textLabel.getTransforms().addAll(invRotY, invRotX);

            // פעולה 3: מזיזים את הטקסט קצת ימינה ולמעלה ביחס לזווית הראייה שלנו
            // (ה-מינוס 1 ב-Z מושך אותו מילימטר אלינו כדי שהכדור שלו עצמו לא יבלע אותו)
            textLabel.getTransforms().add(new javafx.scene.transform.Translate(radius + 5, -radius - 5, -1));

            labelsGroup.getChildren().add(textLabel);
        }
    }

    private void highlightSphere(Sphere s, Color c, double r) {
        if (s == null) return;
        s.setRadius(r); ((PhongMaterial) s.getMaterial()).setDiffuseColor(c);
    }

    public void resetSphereColors() {
        for (Sphere s : sphereToWordMap.keySet()) {
            s.setRadius(4);
            ((PhongMaterial) s.getMaterial()).setDiffuseColor(Color.web("#004488"));
        }
    }

    public void applyProjectionGradient(List<model.ProjectionResult> projection) {
        for (model.ProjectionResult entry : projection) {
            String word = entry.getWord();
            Double val = entry.getProjectionValue();
            javafx.scene.shape.Sphere s = wordToSphereMap.get(word);

            if (s != null) {
                double normalized = 1.0 / (1.0 + Math.exp(-val));
                Color scaleColor = Color.color(normalized, 0, 1.0 - normalized);
                ((javafx.scene.paint.PhongMaterial) s.getMaterial()).setDiffuseColor(scaleColor);
            }
        }
    }

    public void drawLineBetweenWords(String w1, String w2) {
        Sphere s1 = wordToSphereMap.get(w1.trim());
        Sphere s2 = wordToSphereMap.get(w2.trim());
        if (s1 != null && s2 != null) {
            Cylinder line = createConnection(toPoint(s1), toPoint(s2));
            linesGroup.getChildren().add(line);
        }
    }

    public void clearLines() {
        linesGroup.getChildren().clear();
        labelsGroup.getChildren().clear(); // <-- מוחק את הטקסטים הקודמים
    }

    private Cylinder createConnection(Point3D origin, Point3D target) {
        Point3D yAxis = new Point3D(0, 1, 0);
        Point3D diff = target.subtract(origin);
        double height = diff.magnitude();
        Point3D mid = target.midpoint(origin);
        Translate moveToMidpoint = new Translate(mid.getX(), mid.getY(), mid.getZ());
        Point3D axisOfRotation = diff.crossProduct(yAxis);
        double angle = Math.acos(diff.normalize().dotProduct(yAxis));
        Rotate rotateAroundCenter = new Rotate(-Math.toDegrees(angle), axisOfRotation);

        Cylinder line = new Cylinder(0.5, height);
        line.getTransforms().addAll(moveToMidpoint, rotateAroundCenter);
        PhongMaterial mat = new PhongMaterial(Color.ORANGE);
        line.setMaterial(mat);
        return line;
    }

    private Point3D toPoint(Sphere s) {
        return new Point3D(s.getTranslateX(), s.getTranslateY(), s.getTranslateZ());
    }
}
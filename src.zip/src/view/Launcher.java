package view;

import model.VectorSpace;
import utils.PyAdapter;

import java.io.File;

public class Launcher {

    public static void main(String[] args) {
        System.out.println("Starting the Engine...");

        File fullJsonFile = new File("full_vectors.json");
        File pcaJsonFile = new File("pca_vectors.json");

        // חיפוש חלופי בתיקיית data
        if (!fullJsonFile.exists()) fullJsonFile = new File("data/full_vectors.json");
        if (!pcaJsonFile.exists()) pcaJsonFile = new File("data/pca_vectors.json");

        // --- התיקון: אינטגרציה מלאה עם Python (External Process) ---
        if (!fullJsonFile.exists() || !pcaJsonFile.exists()) {
            System.out.println("JSON files missing. Orchestrating Python to generate vectors...");

            // קריאה לפייתון שירוץ כתהליך חיצוני (ProcessBuilder + waitFor)
            boolean pythonSuccess = PyAdapter.runFile();

            if (!pythonSuccess) {
                System.err.println("Critical Error: Python script failed. Cannot start application.");
                return;
            }

            // לאחר שפייתון יצר את הקבצים (בדרך כלל בתיקיית השורש של הפרויקט), נעדכן את הנתיבים
            fullJsonFile = new File("full_vectors.json");
            pcaJsonFile = new File("pca_vectors.json");
        } else {
            System.out.println("JSON files found. Skipping Python execution to save startup time.");
        }
        // -------------------------------------------------------------

        VectorSpace fullSpace = new VectorSpace();
        VectorSpace pcaSpace = new VectorSpace();

        try {
            // הנה הקסם של OOP: אנחנו מייצרים אובייקט מסוג הממשק!
            utils.IDataLoader dataLoader = new utils.JsonVecLoader();

            System.out.println("Loading full vector space for math/logic...");
            // עכשיו קוראים לפונקציה דרך האובייקט (dataLoader) ולא דרך שם המחלקה
            dataLoader.loadVectors(fullJsonFile.getAbsolutePath(), fullSpace);

            System.out.println("Loading PCA vector space for 3D visualization...");
            dataLoader.loadVectors(pcaJsonFile.getAbsolutePath(), pcaSpace);

            System.out.println("Loaded " + fullSpace.getSize() + " words successfully.");
        } catch (Exception e) {
            System.err.println("Error loading vectors. Please ensure JSON files are present.");
            e.printStackTrace();
            return;
        }

        Visualizer visualizer = new JavaFX3DVisualizer();
        visualizer.display(fullSpace, pcaSpace);
    }
}
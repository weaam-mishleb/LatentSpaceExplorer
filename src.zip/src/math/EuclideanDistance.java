package math;

import model.WordEmbedding;
import java.util.Comparator;
import java.util.Map;

public class EuclideanDistance implements Distance {
    @Override
    public double calculate(WordEmbedding v1, WordEmbedding v2) {
        double sum = 0.0;
        int dim = Math.min(v1.getDimension(), v2.getDimension());
        for (int i = 0; i < dim; i++) {
            sum += Math.pow(v1.getCoordinate(i) - v2.getCoordinate(i), 2);
        }
        return Math.sqrt(sum);
    }

    @Override
    public String getName() { return "Euclidean Distance"; }

    @Override
    public Comparator<Map.Entry<WordEmbedding, Double>> getResultComparator() {
        return Map.Entry.comparingByValue();
    }
}
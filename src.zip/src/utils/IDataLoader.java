package utils;
import model.VectorSpace;
import exceptions.DataLoadingException;

public interface IDataLoader {
    void loadVectors(String filePath, VectorSpace space) throws DataLoadingException;
}
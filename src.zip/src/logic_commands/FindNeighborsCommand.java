package logic_commands;

import exceptions.WordNotFoundException;
import logic.AnalysisService;
import model.SearchResult;
import utils.AppConstants;
import view.SceneRenderer;
import javafx.scene.control.Label;
import java.util.List;

public class FindNeighborsCommand extends AbstractVisualCommand {
    private final AnalysisService service;
    private final String searchWord;
    private final int k;

    public FindNeighborsCommand(AnalysisService service, SceneRenderer renderer, Label resultLabel, String prevWord, String searchWord, int k) {
        super(renderer, resultLabel, prevWord);
        this.service = service;
        this.searchWord = searchWord.trim();
        this.targetWord = this.searchWord; // שומרים את מילת המטרה ל-Undo עתידי
        this.k = k; // <--- זו השורה שהייתה חסרה!
    }

    @Override
    protected void doExecute() {
        try {
            List<SearchResult> neighbors = service.findNearestNeighbors(searchWord, k);
            if (neighbors.isEmpty()) {
                resultLabel.setText("Word not found.");
                return;
            }

            renderer.highlightWord(searchWord, AppConstants.COLOR_ANALOGY_RESULT, AppConstants.RADIUS_TARGET);
            for (SearchResult entry : neighbors) {
                String neighborWord = entry.getWord();
                renderer.highlightWord(neighborWord, AppConstants.COLOR_NEIGHBOR, AppConstants.RADIUS_NEIGHBOR);
                renderer.drawLineBetweenWords(searchWord, neighborWord);
            }
            renderer.zoomToWord(searchWord);
            resultLabel.setText("Showing " + k + " neighbors for: " + searchWord);

        } catch (WordNotFoundException ex) {
            resultLabel.setText(ex.getMessage());
        }
    }
}
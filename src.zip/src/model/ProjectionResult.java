package model;

public class ProjectionResult {
    private final String word;
    private final double projectionValue;

    public ProjectionResult(String word, double projectionValue) {
        this.word = word;
        this.projectionValue = projectionValue;
    }

    public String getWord() { return word; }
    public double getProjectionValue() { return projectionValue; }
}
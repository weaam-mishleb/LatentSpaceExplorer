package logic_commands;

import logic.AnalysisService;
import utils.AppConstants;
import view.SceneRenderer;
import javafx.scene.control.Label;
import java.util.OptionalDouble;

public class CalculateDistanceCommand extends AbstractVisualCommand {
    private final AnalysisService service;
    private final String word1, word2;

    public CalculateDistanceCommand(AnalysisService service, SceneRenderer renderer, Label resultLabel, String prevWord, String w1, String w2) {
        super(renderer, resultLabel, prevWord);
        this.service = service;
        this.word1 = w1.trim();
        this.word2 = w2.trim();
        this.targetWord = word1;
    }

    @Override
    protected void doExecute() {
        OptionalDouble distOpt = service.getDistance(word1, word2);
        if (distOpt.isEmpty()) {
            resultLabel.setText("Error: Words not found.");
            return;
        }
        renderer.highlightWord(word1, AppConstants.COLOR_CENTROID, AppConstants.RADIUS_NEIGHBOR);
        renderer.highlightWord(word2, AppConstants.COLOR_CENTROID, AppConstants.RADIUS_NEIGHBOR);
        renderer.drawLineBetweenWords(word1, word2);
        resultLabel.setText(String.format("Distance: %.4f", distOpt.getAsDouble()));
        renderer.focusOnTwoPoints(word1, word2);
    }
}
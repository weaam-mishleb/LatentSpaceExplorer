package logic_commands;

import exceptions.WordNotFoundException;
import logic.AnalysisService;
import model.ProjectionResult;
import utils.AppConstants;
import view.SceneRenderer;
import javafx.scene.control.Label;
import java.util.List;

public class ShowProjectionCommand extends AbstractVisualCommand {
    private final AnalysisService service;
    private final String startWord, endWord;

    public ShowProjectionCommand(AnalysisService service, SceneRenderer renderer, Label resultLabel, String prevWord, String start, String end) {
        super(renderer, resultLabel, prevWord);
        this.service = service;
        this.startWord = start.trim();
        this.endWord = end.trim();
        this.targetWord = startWord;
    }

    @Override
    protected void doExecute() {
        renderer.highlightWord(startWord, AppConstants.COLOR_AXIS, AppConstants.RADIUS_AXIS);
        renderer.highlightWord(endWord, AppConstants.COLOR_AXIS, AppConstants.RADIUS_AXIS);
        renderer.drawLineBetweenWords(startWord, endWord);

        try {
            List<ProjectionResult> projection = service.projectWordsOnAxis(startWord, endWord, 5000);
            if(!projection.isEmpty()) {
                renderer.applyProjectionGradient(projection);
                resultLabel.setText("Projection: " + startWord + " -> " + endWord);
                renderer.focusOnTwoPoints(startWord, endWord);
            }
        } catch (WordNotFoundException ex) {
            resultLabel.setText("Error: " + ex.getMessage());
        }
    }
}
package math;

import model.WordEmbedding;
import java.util.Comparator;
import java.util.Map;

public interface Distance {
    double calculate(WordEmbedding v1, WordEmbedding v2);
    String getName();
    Comparator<Map.Entry<WordEmbedding, Double>> getResultComparator();
}
package logic_commands;

import utils.AppConstants;
import view.SceneRenderer;
import javafx.scene.control.Label;

public class ZoomToWordCommand extends AbstractVisualCommand {
    private final String searchWord;

    public ZoomToWordCommand(SceneRenderer renderer, Label resultLabel, String prevWord, String searchWord) {
        super(renderer, resultLabel, prevWord);
        this.searchWord = searchWord.trim();
        this.targetWord = this.searchWord;
    }

    @Override
    protected void doExecute() {
        renderer.highlightWord(searchWord, AppConstants.COLOR_TARGET, AppConstants.RADIUS_TARGET);
        renderer.zoomToWord(searchWord);
        resultLabel.setText("Found: " + searchWord);
    }
}
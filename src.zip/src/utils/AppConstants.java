package utils;

import javafx.scene.paint.Color;

public class AppConstants {
    // צבעים
    public static final Color COLOR_TARGET = Color.CYAN;
    public static final Color COLOR_NEIGHBOR = Color.LIMEGREEN;
    public static final Color COLOR_ANALOGY_RESULT = Color.GOLD;
    public static final Color COLOR_CENTROID = Color.ORANGE;
    public static final Color COLOR_AXIS = Color.MAGENTA;

    // רדיוסים (גדלים של הכדורים)
    public static final int RADIUS_TARGET = 12;
    public static final int RADIUS_NEIGHBOR = 8;
    public static final int RADIUS_CENTROID = 6;
    public static final int RADIUS_ANALOGY_RESULT = 14;
    public static final int RADIUS_AXIS = 10;
}
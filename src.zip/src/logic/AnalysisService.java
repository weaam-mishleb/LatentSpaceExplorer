package logic;

import exceptions.WordNotFoundException;
import model.ProjectionResult;
import model.SearchResult;
import model.VectorSpace;
import model.WordEmbedding;
import math.Distance;
import math.VectorMath;

import java.util.*;
import java.util.stream.Collectors;

public class AnalysisService {
    private final VectorSpace space;
    private Distance metric;

    public AnalysisService(VectorSpace space, Distance defaultMetric) {
        this.space = space;
        this.metric = defaultMetric;
    }

    public void setMetric(Distance metric) { this.metric = metric; }
    public Distance getMetric() { return metric; }

    // עכשיו מחזיר רשימה של SearchResult!
    public List<SearchResult> findNearestNeighbors(String targetWord, int k) {
        WordEmbedding targetVec = space.getEmbedding(targetWord);
        if (targetVec == null) throw new WordNotFoundException(targetWord);

        return space.getAllEmbeddings().parallelStream()
                .filter(w -> !w.getWord().equals(targetWord))
                .map(w -> new AbstractMap.SimpleEntry<>(w, metric.calculate(targetVec, w)))
                .sorted(metric.getResultComparator())
                .limit(k)
                .map(entry -> new SearchResult(entry.getKey(), entry.getValue())) // ממיר ל-DTO
                .collect(Collectors.toList());
    }

    public OptionalDouble getDistance(String w1, String w2) {
        WordEmbedding v1 = space.getEmbedding(w1);
        WordEmbedding v2 = space.getEmbedding(w2);
        if (v1 == null || v2 == null) return OptionalDouble.empty();
        return OptionalDouble.of(metric.calculate(v1, v2));
    }

    public SearchResult computeAnalogy(String a, String b, String c) {
        WordEmbedding vA = space.getEmbedding(a);
        WordEmbedding vB = space.getEmbedding(b);
        WordEmbedding vC = space.getEmbedding(c);
        if (vA == null || vB == null || vC == null) return null;

        double[] targetVector = VectorMath.calculateAnalogyVector(vA, vB, vC);
        WordEmbedding targetEmb = new WordEmbedding("TARGET_TEMP", targetVector);

        return space.getAllEmbeddings().parallelStream()
                .filter(w -> !w.getWord().equals(a) && !w.getWord().equals(b) && !w.getWord().equals(c))
                .map(w -> new AbstractMap.SimpleEntry<>(w, metric.calculate(targetEmb, w)))
                .min(metric.getResultComparator())
                .map(entry -> new SearchResult(entry.getKey(), entry.getValue())) // ממיר ל-DTO
                .orElse(null);
    }

    public WordEmbedding getCentroidVector(List<String> words) {
        if (words == null || words.isEmpty()) return null;
        List<WordEmbedding> validEmbeddings = words.stream()
                .map(w -> space.getEmbedding(w.trim()))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        if (validEmbeddings.isEmpty()) return null;

        double[] sumVector = VectorMath.calculateAverageVector(validEmbeddings);
        return new WordEmbedding("CENTROID_TEMP", sumVector);
    }

    public List<SearchResult> getKNearestToVector(WordEmbedding targetVec, int k, List<String> excludeWords) {
        if (targetVec == null) return Collections.emptyList();
        return space.getAllEmbeddings().parallelStream()
                .filter(w -> excludeWords == null || !excludeWords.contains(w.getWord()))
                .map(w -> new AbstractMap.SimpleEntry<>(w, metric.calculate(targetVec, w)))
                .sorted(metric.getResultComparator())
                .limit(k)
                .map(entry -> new SearchResult(entry.getKey(), entry.getValue())) // ממיר ל-DTO
                .collect(Collectors.toList());
    }

    // עכשיו מחזיר ProjectionResult!
    public List<ProjectionResult> projectWordsOnAxis(String startWord, String endWord, int limit) {
        WordEmbedding vStart = space.getEmbedding(startWord);
        WordEmbedding vEnd = space.getEmbedding(endWord);
        if (vStart == null || vEnd == null) throw new WordNotFoundException(startWord + " or " + endWord);

        int dim = vStart.getDimension();
        double[] axisVector = new double[dim];
        double axisNormSq = 0;
        for(int i=0; i<dim; i++) {
            axisVector[i] = vEnd.getCoordinate(i) - vStart.getCoordinate(i);
            axisNormSq += axisVector[i] * axisVector[i];
        }
        final double finalAxisNormSq = axisNormSq;

        return space.getAllEmbeddings().parallelStream()
                .map(w -> {
                    double dot = 0;
                    for(int i=0; i<dim; i++) {
                        double wVecRelative = w.getCoordinate(i) - vStart.getCoordinate(i);
                        dot += wVecRelative * axisVector[i];
                    }
                    double projection = dot / finalAxisNormSq;
                    return new ProjectionResult(w.getWord(), projection); // ממיר ל-DTO
                })
                // מיון פשוט של ה-DTO לפי הערך
                .sorted(Comparator.comparingDouble(ProjectionResult::getProjectionValue))
                .limit(limit)
                .collect(Collectors.toList());
    }
}
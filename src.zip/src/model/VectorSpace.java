package model;

import exceptions.DimensionMismatchException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VectorSpace {
    private final List<WordEmbedding> storage;
    // שדרוג O(1) לחיפוש מהיר!
    private final Map<String, WordEmbedding> quickLookup;
    private int dimensions = -1;

    public VectorSpace() {
        this.storage = new ArrayList<>();
        this.quickLookup = new HashMap<>();
    }

    public void addWord(WordEmbedding word) {
        if (word == null) return;
        if (dimensions == -1) {
            dimensions = word.getDimension();
        } else if (word.getDimension() != dimensions) {
            // שימוש בחריגה המותאמת אישית שלנו!
            throw new DimensionMismatchException(dimensions, word.getDimension());
        }
        storage.add(word);
        quickLookup.put(word.getWord(), word);
    }

    public WordEmbedding getEmbedding(String word) {
        return quickLookup.get(word); // חיפוש מיידי!
    }

    public List<WordEmbedding> getAllEmbeddings() {
        return Collections.unmodifiableList(storage); // הגנה על הרשימה (Encapsulation)
    }

    public int getSize() { return storage.size(); }
    public int getDimensions() { return dimensions; }
}
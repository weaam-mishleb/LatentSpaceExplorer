package logic_commands;
import logic.Command;
import view.SceneRenderer;
import javafx.scene.control.Label;
import utils.AppConstants;
public abstract class AbstractVisualCommand implements Command {
    protected final SceneRenderer renderer;
    protected final Label resultLabel;
    private final String prevWord;
    protected String targetWord; // המילה שהמצלמה תתמקד בה בסוף הפעולה

    public AbstractVisualCommand(SceneRenderer renderer, Label resultLabel, String prevWord) {
        this.renderer = renderer;
        this.resultLabel = resultLabel;
        this.prevWord = prevWord;
    }

    @Override
    public void execute() {
        renderer.clearLines();
        renderer.resetSphereColors();
        doExecute(); // Template Method - קורא למימוש של המחלקה היורשת
    }

    // כל מחלקה ספציפית תממש רק את החלק הזה!
    protected abstract void doExecute();

    @Override
    public void undo() {
        renderer.clearLines();
        renderer.resetSphereColors();
        if (prevWord != null) {
            renderer.highlightWord(prevWord, AppConstants.COLOR_TARGET, AppConstants.RADIUS_TARGET);
            renderer.zoomToWord(prevWord);
            resultLabel.setText("Undo: Back to " + prevWord);
        } else {
            renderer.resetCamera();
            resultLabel.setText("Undo: Reset view");
        }
    }

    public String getTargetWord() {
        return targetWord;
    }
}
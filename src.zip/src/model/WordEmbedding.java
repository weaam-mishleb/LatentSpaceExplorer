package model;
import java.util.Arrays;
public class WordEmbedding {
    private final String word;
    private final double[] vector;

    public WordEmbedding(String word, double[] vector) {
        if (word == null || vector == null) {
            throw new IllegalArgumentException("the word or the vector cannot be null");
        }
        this.word = word;
        this.vector = Arrays.copyOf(vector, vector.length);;
    }
    public double[] getVector() {
        return Arrays.copyOf(vector, vector.length);
    }

    public String getWord() {
        return word;
    }

    public double getCoordinate(int index) {
        if (index < 0 || index >= vector.length) {
            throw new IndexOutOfBoundsException();
        }
        return vector[index];
    }
    public int getDimension() {
        return vector.length;
    }
}
